
# Hands-On 3: Pandas Lanjutan

Dataset: Student Performance (EdTech)

Tahapan pengerjaan:
1. Memuat dataset.
2. Memeriksa kualitas data.
3. Membersihkan data.
4. Melakukan analisis menggunakan GroupBy.
5. Membuat visualisasi.
6. Melakukan preprocessing.
7. Menyimpan hasil pengolahan data.

Tools:
- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- Google Colab
